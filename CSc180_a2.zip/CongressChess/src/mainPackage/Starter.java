package mainPackage;

import java.io.Console;
import java.util.Arrays;
import mainPackage.BoardBuilder;
/*=====================================================================================//
|                                   Zachary Schuett                                     |
|										CSc 180                                         |
|									Congress Chess	                                    |
|                                      RED   DAWN                                       |
//=====================================================================================*/

/*LOGIC:
 * The starter class should handle all of the logic in regards to the correct movements to 
 * be made.  It should also update the game board as well as the score.
 */
public class Starter {
//GLOBALS//
	boolean humanTurn = false;
	boolean cpuTurn   = false;
	
	
	
	
	
	public Starter() {}


//===================================================//
//POSSIBLE MOVEMENTS__________________________________|

	
	
//POSSIBLE MOVEMENTS__________________________________|
	public void updateBoard() {//updates the board after each player move, whether it is CPU or human made
		
	}
	public void gameLoop() {   // tests the win condition, if it is false, then keep the game running, otherwise, print out winner.  DO NOT CLOSE WINDOW
		
	}
	
	public static void main(String[] args) {	
		BoardBuilder board = new BoardBuilder();
		board.returnBoard();
	}
	
	

}


