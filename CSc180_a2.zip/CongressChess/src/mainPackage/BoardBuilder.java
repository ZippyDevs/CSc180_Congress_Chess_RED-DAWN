package mainPackage;

import java.lang.reflect.Array;


public class BoardBuilder {
	
	//public static final String ANSI_GREEN = "\u001B[32m";
	
	
	String[][] board = new String[9][];
	//PIECE VAR INSTANTIATION (CPU)
		static String U   = "- ";
		static String X   = "| ";
		static String Y   = "_ ";
		static String H   = "H ";
		static String K   = "K ";
		static String B   = "B ";
		static String P   = "P ";
		static String Cpu = "	(CPU)";
	//PIECE VAR INSTANTIATION (HUMAN)
		static String h   = "h ";
		static String k   = "k ";
		static String b   = "b ";
		static String p   = "p ";
		static String Hum = "	(HUMAN)";
		
		static String nl = "\n";
		static String s  = " ";
		
		static String A = "A ";
		static String C = "C ";
		static String D = "D ";
		static String E = "E ";
		static String F = "F ";
		static String G = "G ";
		static String Hi = "H ";
		
	public BoardBuilder() {
		 board = new String[][]{
			 
			 {s,  Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,       nl},
			 {s,  Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Cpu,   nl},
			 {"6",X,X,H,H,U,K,K,U,B,B,X,X,       nl},
			 {"5",X,X,U,P,P,P,P,P,P,U,X,X,       nl},
			 {"4",X,X,U,U,U,U,U,U,U,U,X,X,       nl},
			 {"3",X,X,U,U,U,U,U,U,U,U,X,X,       nl},
			 {"2",X,X,U,p,p,p,p,p,p,U,X,X,       nl},
			 {"1",X,X,h,h,U,k,k,U,b,b,X,X,       nl}, 
			 {s,  Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Hum,   nl},
			 {s,  Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,Y,       nl},
			 {s,s,s,s,A,B,C,D,E,F,G,Hi,          nl}
			 
		};
		
	}
	protected void returnBoard() {
		//board = new String[9][13];
		int row = board.length;
		int col;
		
		for(int i=0; i<row; i++) {
			col = board[i].length;
			for(int j=0; j<col; j++) {
				System.out.print(board[i][j]+" ");
			}
			System.out.println();
		}
	}	
}
