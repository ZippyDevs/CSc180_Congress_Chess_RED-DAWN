package chessPieces;

import mainPackage.BoardBuilder;

/*RULES
 * --Moves roughly the same as a pawn in regular chess
 * --cannot move sideways or backwards UNDER ANY CIRCUMSTANCES
 * --only move forward forward or forward diagonal movement
 */
public class Pawn {

	
	private void makeMove(BoardBuilder b[][]) {
		
	}

}
