package chessPieces;

import mainPackage.BoardBuilder;

/*RULES:
 * --Each king can move one square at a time, horizontally in the direction AWAY from the other king.
 * --LeftWing moves left, RightWing moves right.
 * --When both of your kings are captured, YOU LOSE!
 */
public class King {
	
	
	private void makeMove(BoardBuilder b[][]) {
		
	}

}
