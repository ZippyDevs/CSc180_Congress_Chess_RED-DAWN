package chessPieces;

import mainPackage.BoardBuilder;

/*RULES:
 * --Moves roughly the same as the knight in regular chess
 * --May move onto an empty square or an occupied one
 * --CAN jump over other pieces
 * --Junior horse may only move forward
 * --Senior horse may move backwards (ONLY TO CAPTURE)
 */
public class Horse {

	
	private void makeMove(BoardBuilder b[][]) {
		
	}
}
