package chessPieces;

import mainPackage.BoardBuilder;

/*RULES:
 * --Moves roughly the same as the bishop in regular chess. (DIAGONAL)
 * --May move onto an empty square or onto an occupied one.
 * --CANNOT jump over other pieces.  Once it has hit a piece, that is the end of its turn.
 * --JUNIOR bishops my only move forward.
 * --SENIOR bishops may move backwards (ONLY TO CAPTURE)
 */
public class Bishop {
	public Bishop() {}
	
	private void makeMove(BoardBuilder b[][]) {
		
	}
}
